package trendyol;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static java.lang.Thread.sleep;


public class Trendyol {


    public static void main(String[] args) {


        System.setProperty("webdriver.chrome.driver","C:/Users/hp/Desktop/Selenium/Chromedriver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.trendyol.com/giris?cb=https%3A%2F%2Fwww.trendyol.com%2F");
        driver.manage().window().maximize();

        driver.findElement(By.id("login-email")).click();
        driver.findElement(By.name("login email")).sendKeys("dehayarapsanli@hotmail.com");

        driver.findElement(By.className("search-box")).click();

        driver.findElement(By.id("login-password-input")).click();
        driver.findElement(By.name("login-password")).sendKeys("13091992");
        driver.findElement(By.className("q-primary")).click();
        driver.findElement(By.className("tab-link active")).click();
        driver.findElement(By.xpath("//a[@class='category-header'][3]")).click();






    }
}
