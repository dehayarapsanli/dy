package şahsi;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import static java.lang.Thread.sleep;


public class trendyolwebpage {


    public static void main(String[] args) {


        System.setProperty("webdriver.chrome.driver","C:/Users/hp/Desktop/Selenium/Chromedriver/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.trendyol.com");
        driver.get("https://www.google.com");
        driver.manage().window().maximize();
        driver.findElement(By.name("q")).sendKeys("yarapsanlı");
        try {
            sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.findElement(By.className("gNO89b")).click();


    }
}
